print("hello world")
print