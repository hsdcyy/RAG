print("hello world")
print("my name is ")